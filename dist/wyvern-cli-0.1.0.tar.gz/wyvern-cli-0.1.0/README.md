# Wyvern CLI

Pterodactyl CLI interface and automation